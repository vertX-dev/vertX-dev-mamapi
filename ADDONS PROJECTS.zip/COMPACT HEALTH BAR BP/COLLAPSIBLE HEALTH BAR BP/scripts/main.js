import { world, system, HudElement, HudVisibility, EquipmentSlot } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";

// =============================================================================
// CONSTANTS
// =============================================================================

const healthBars = [
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""],
  ["","","","","","","","","","","","","","","","","","","",""]
];

// Settings tags for players
const SETTINGS_TAGS = {
    SHOW_ROWS: "chb_show_rows", 
    SHOW_NUMBERS: "chb_show_numbers",
    SHOW_HEALTH_BAR: "chb_show_healthbar"
};

// =============================================================================
// UTILITY FUNCTIONS
// =============================================================================

/**
 * Gets a scoreboard value for a player
 * @param {string} scoreboardName - Name of the scoreboard
 * @param {Player} player - The player to check
 * @returns {number} The score value, or 0 if not found
 */
function getScoreboardValue(scoreboardName, player) {
    try {
        const scoreboardObj = world.scoreboard.getObjective(scoreboardName);
        if (!scoreboardObj) return 0;
        
        const score = scoreboardObj.getScore(player);
        return score ?? 0;
    } catch (error) {
        console.warn(`Failed to get scoreboard value for ${scoreboardName}:`, error.message);
        return 0;
    }
}

/**
 * Safely adds score to a player's scoreboard
 * @param {string} scoreboardName - Name of the scoreboard
 * @param {Player} player - The player to add score to
 * @param {number} amount - Amount to add
 */
function addScoreToPlayer(scoreboardName, player, amount) {
    try {
        const scoreboardObj = world.scoreboard.getObjective(scoreboardName);
        if (scoreboardObj) {
            scoreboardObj.addScore(player, amount);
        }
    } catch (error) {
        console.warn(`Failed to add score to ${scoreboardName}:`, error.message);
    }
}

/**
 * Gets a player's setting value
 * @param {Player} player - The player to check
 * @param {string} settingTag - The setting tag to check
 * @returns {boolean} Whether the setting is enabled
 */
function getPlayerSetting(player, settingTag) {
    return player.hasTag(settingTag);
}

/**
 * Sets a player's setting value
 * @param {Player} player - The player to modify
 * @param {string} settingTag - The setting tag to modify
 * @param {boolean} enabled - Whether to enable or disable the setting
 */
function setPlayerSetting(player, settingTag, enabled) {
    if (enabled) {
        if (!player.hasTag(settingTag)) {
            player.addTag(settingTag);
        }
    } else {
        if (player.hasTag(settingTag)) {
            player.removeTag(settingTag);
        }
    }
}

// =============================================================================
// HEALTH DISPLAY SYSTEM
// =============================================================================

/**
 * Displays the health bar for a player
 * @param {Player} player - The player to display health for
 */
function displayHealthBar(player) {
    try {
        const healthComponent = player.getComponent("minecraft:health");
        if (!healthComponent) return;
        
        // Check if health bar display is enabled
        const showHealthBar = getPlayerSetting(player, SETTINGS_TAGS.SHOW_HEALTH_BAR);
        if (!showHealthBar) return;
        
        const maxHp = healthComponent.effectiveValue;
        const currentHp = healthComponent.currentValue;
        
        const { row, column, rowAbs } = calculateHealthBarPosition(currentHp);
        const healthBarString = formatHealthBarString(row, column, currentHp, rowAbs, player);
        
        // Update title with health bar
        player.runCommand("title @s times 0 0 0");
        player.runCommand(`title @s title hpc:${healthBarString}`);
        
    } catch (error) {
        console.warn(`Failed to display health bar for player:`, error.message);
    }
}

/**
 * Calculates the row and column position for the health bar
 * @param {number} currentHp - Current HP value
 * @returns {Object} Object containing row and column
 */
function calculateHealthBarPosition(currentHp) {
    const col = Math.floor(currentHp % 20);
    const rowAbs = Math.floor((currentHp / 20) - 0.001);
    
    let row;
    if (rowAbs <= 12) {
        row = rowAbs;
    } else {
        row = ((rowAbs - 13) % 12) + 1;
    }

    // Reverse the column (keeping original logic)
    let reversedCol = 20 -1 - col;
    if (col === 0) reversedCol = col;

    return { row, column: reversedCol, rowAbs };
}

/**
 * Formats the health bar string for display
 * @param {number} row - Row index
 * @param {number} column - Column index  
 * @param {number} currentHp - Current HP value
 * @param {number} rowAbs - Absolute row value
 * @param {Player} player - The player (for settings)
 * @returns {string} Formatted health bar string
 */
function formatHealthBarString(row, column, currentHp, rowAbs, player) {
    let result = healthBars[row][column];
    
    const showRows = getPlayerSetting(player, SETTINGS_TAGS.SHOW_ROWS);
    const showNumbers = getPlayerSetting(player, SETTINGS_TAGS.SHOW_NUMBERS);
    
    if (showRows) {
        result += ` x${rowAbs + 1}`;
    }
    
    if (showNumbers) {
        result += `  ${Math.ceil(currentHp)}`;
    }
    
    return result;
}

/**
 * Processes all players for health display
 */
function updateAllPlayersHealth(event) {
    const entity = event.entity;
    // Only apply to players
    if (!entity || entity.typeId !== "minecraft:player") return;
    displayHealthBar(entity);
}

// =============================================================================
// COMMAND SYSTEM
// =============================================================================

/**
 * Handles chat commands
 * @param {ChatSendBeforeEvent} event - The chat event
 */
function handleChatCommands(event) {
    const player = event.sender;
    const message = event.message;
    
    if (!message.startsWith(".")) return;
    
    switch (message) {
        case ".chb":
            event.cancel = true;
            system.runTimeout(() => openSettings(player), 60);
            break;
        case ".rh":
            event.cancel = true;
            system.runTimeout(() => displayHealthBar(player), 60);
            break;
        default:
            break;
    }
}

/**
 * Opens settings UI for a player
 * @param {Player} player - The player to show settings to
 */
function openSettings(player) {
    try {
        const form = new ModalFormData();
        form.title("Health Bar Settings");
        
        // Get current settings
        const showRows = getPlayerSetting(player, SETTINGS_TAGS.SHOW_ROWS);
        const showNumbers = getPlayerSetting(player, SETTINGS_TAGS.SHOW_NUMBERS);
        const showHealthBar = getPlayerSetting(player, SETTINGS_TAGS.SHOW_HEALTH_BAR);
        // Add form elements
        form.toggle("Show amount of rows", { defaultValue: showRows });
        form.toggle("Show health amount in numbers", { defaultValue: showNumbers });
        form.toggle("Show health bar", { defaultValue: showHealthBar });
        // Show form to player
        form.show(player).then((response) => {
            if (response.canceled) {
                return;
            }
            
            // Process form response - handle NaN values from divider elements
            const formValues = response.formValues || [];
            let valueIndex = 0;
            
            // Extract values, filtering out NaN values from dividers
            const validValues = formValues.filter(value => !isNaN(value));
            
            if (validValues.length >= 3) {
                // Apply settings based on form values
                setPlayerSetting(player, SETTINGS_TAGS.SHOW_ROWS, Boolean(validValues[0]));
                setPlayerSetting(player, SETTINGS_TAGS.SHOW_NUMBERS, Boolean(validValues[1]));
                setPlayerSetting(player, SETTINGS_TAGS.SHOW_HEALTH_BAR, Boolean(validValues[2]));
                
                player.sendMessage("§aHealth bar settings updated!");
            } else {
                player.sendMessage("§cError: Invalid form response");
            }
        });
        
    } catch (error) {
        console.warn(`Failed to open settings for player:`, error.message);
        player.sendMessage("§cFailed to open settings menu");
    }
}

// =============================================================================
// EVENT HANDLERS & INITIALIZATION
// =============================================================================

/**
 * Initialize the health bar system
 */
function initializeSystem() {
    console.log("Initializing Health Bar System...");
    
    // Initialize scoreboards with delay
    system.runInterval(() => {
        const players = world.getPlayers();
        for (const player of players) {
            displayHealthBar(player);
        }
    }, 200);
    
    
    // Initialize default settings for new players
    system.runInterval(() => {
        const players = world.getPlayers();
        for (const player of players) {
            if (!player.hasTag("chb_settings_initialized")) {
                // Set default settings
                setPlayerSetting(player, SETTINGS_TAGS.SHOW_ROWS, true);
                setPlayerSetting(player, SETTINGS_TAGS.SHOW_NUMBERS, true);
                setPlayerSetting(player, SETTINGS_TAGS.SHOW_HEALTH_BAR, true);
                
                player.addTag("chb_settings_initialized");
            }
        }
    }, 200); // Check every 10 seconds
    
    console.log("Health Bar System initialized!");
}

// =============================================================================
// EVENT SUBSCRIPTIONS
// =============================================================================

// Subscribe to chat events for commands
world.beforeEvents.chatSend.subscribe(handleChatCommands);

world.afterEvents.entityHealthChanged.subscribe(updateAllPlayersHealth);

// Initialize the system
initializeSystem();